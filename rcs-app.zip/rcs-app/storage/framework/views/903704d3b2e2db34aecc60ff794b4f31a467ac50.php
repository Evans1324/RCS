

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card">
            <div class="card-header">
                <h1 class="card-title">Form 56 (Real Property Tax)</h1>
            </div>
            <div class="card-body">
                <div class="col-md-12">
                    <form name="form56_form" id="form56_form" method="post" action="<?php echo e(url('update_form56')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="inputEffectivityYear">EFFECTIVITY YEAR</label>
                                        <input type="text" name="inputEffectivityYear"
                                            class="yearpicker form-control mb-0 bg-white text-dark"
                                            id="inputEffectivityYear" value="<?php echo e(old('inputEffectivityYear')); ?>">
                                        <label class="text-danger">
                                            <?php $__errorArgs = ['inputEffectivityYear'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="inputTaxPercentage">TAX PERCENTAGE TO BE COLLECTED</label>
                                        <input type="text" name="inputTaxPercentage"
                                            class="form-control mb-0 bg-white text-dark" id="inputTaxPercentage"
                                            value="<?php echo e(old('inputTaxPercentage')); ?>">
                                        <label class="text-danger">
                                            <?php $__errorArgs = ['inputTaxPercentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="inputAidFull">ADVANCED PAYMENT DISCOUNT</label>
                                        <input type="text" name="inputAidFull" class="form-control mb-0 bg-white text-dark"
                                            id="inputAidFull" value="<?php echo e(old('inputAidFull')); ?>">
                                        <label class="text-danger">
                                            <?php $__errorArgs = ['inputAidFull'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="inputPaidFull">PROMPT PAYMENT DISCOUNT</label>
                                        <input type="text" name="inputPaidFull" class="form-control mb-0 bg-white text-dark"
                                            id="inputPaidFull" value="<?php echo e(old('inputPaidFull')); ?>">
                                        <label class="text-danger">
                                            <?php $__errorArgs = ['inputPaidFull'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="inputPenaltyPerMonth">PENALTY PER MONTH</label>
                                        <input type="text" name="inputPenaltyPerMonth"
                                            class="form-control mb-0 bg-white text-dark" id="inputPenaltyPerMonth"
                                            value="<?php echo e(old('inputPenaltyPerMonth')); ?>">
                                        <label class="text-danger">
                                            <?php $__errorArgs = ['inputPenaltyPerMonth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 d-flex justify-content-center">
                                        <button type="button" id="updateForm56" class="update-btn btn btn-success">Update
                                            Form</button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="col-md-12">
                                    <div class="card-header">
                                        <h4 class="card-title">District Hospital Remittance</h4>
                                        
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table tablesorter " id="form56-table">
                                                <thead class=" text-primary">
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Effectivity Year</th>
                                                        <th>Tax Percentage to be Collected</th>
                                                        <th>Aid in Full Before January</th>
                                                        <th>Paid in Full From January 1 to March 31</th>
                                                        <th>Penalty Per Month</th>
                                                        <th>Created At</th>
                                                        <th>Updated At</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <script>
        let data = <?php echo json_encode($form56Table, 15, 512) ?>;
        $(document).ready(function() {
            let table = $('#form56-table').DataTable({
                data: data,
                columns: [{
                        'data': 'id'
                    },
                    {
                        'data': 'effectivity_year'
                    },
                    {
                        'data': 'tax_precentage'
                    },
                    {
                        'data': 'aid_in_full'
                    },
                    {
                        'data': 'paid_in_full'
                    },
                    {
                        'data': 'penalty_per_month'
                    },
                    {
                        'data': 'created_at'
                    },
                    {
                        'data': 'updated_at'
                    }
                ]
            });
        });

        $(".yearpicker").datepicker({
            format: 'yyyy',
            viewMode: "years",
            minViewMode: "years",
            autoclose: true
        });

        let oldInputs = <?php echo json_encode(count(Session::getOldInput()), 15, 512) ?>;
        
        if (oldInputs == 0) {
            let form56Input = <?php echo json_encode($form56, 15, 512) ?>;
            console.log(form56Input);
            $('#inputEffectivityYear').val(form56Input.effectivity_year);
            $('#inputTaxPercentage').val(form56Input.tax_precentage);
            $('#inputAidFull').val(form56Input.aid_in_full);
            $('#inputPaidFull').val(form56Input.paid_in_full);
            $('#inputPenaltyPerMonth').val(form56Input.penalty_per_month);
        }
        

        $('#updateForm56').on('click', function(e) {
            let $form = $(this);
            Swal.fire({
                icon: 'info',
                title: 'Form will be updated. Are you sure you want to proceed?',
                showCancelButton: true,
                confirmButtonText: 'Update',
            }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.isConfirmed) {
                    Swal.fire('Updated Successfully!', '', 'success')
                    $('#form56_form').submit();
                } else if (result.isDenied) {
                    Swal.fire('Changes are not saved', '', 'info')
                }
            })
        });

        console.log(oldInputs);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => __('Form 56'), 'pageSlug' => 'form_56'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rcs-app\resources\views/pages/form_56.blade.php ENDPATH**/ ?>