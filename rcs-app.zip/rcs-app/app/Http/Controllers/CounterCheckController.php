<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PhpOffice\PhpWord\TemplateProcessor;
use Illuminate\Support\Facades\DB;
use App\Models\LandTaxInfo;

class CounterCheckController extends Controller
{
    public function generateProvIncomeCounterCheck(Request $request) {

        $startDate = Date('Y-m-d', strtotime($request->startDate));
        $endDate = Date('Y-m-d', strtotime($request->endDate));
        
        $landTaxInfo = LandTaxInfo::select('rentals.*', 'rentals.name AS rental_name', 'land_tax_accounts.nature', 'barangays.*', 'municipalities.*', 'land_tax_infos.*', DB::raw('sum(land_tax_accounts.amount) as totalAmount'))
        ->where([['land_tax_accounts.account', $request->accTitle], ['land_tax_infos.submission_type', 'Revenue Collection']])
        ->whereBetween('land_tax_infos.report_date', [$startDate, $endDate])
        ->orderBy('report_date', 'asc')
        ->join('land_tax_accounts', 'land_tax_accounts.info_id', 'land_tax_infos.id')
        ->leftJoin('municipalities', 'municipalities.id', 'land_tax_infos.municipality_id')
        ->leftJoin('barangays', 'barangays.id', 'land_tax_infos.barangay_id')
        ->leftJoin('rentals', 'land_tax_infos.lot_rental_id', 'rentals.id')
        ->groupBy('serial_number')
        ->distinct()
        ->get();

        $occurences = count($landTaxInfo);

        $file = public_path('storage/WordTemplates/AccountTitlesCounterCheck.docx');
        $templateProcessor = new TemplateProcessor($file);
        $grandTotal = 0;
        
        $templateProcessor->setValue('startRangeDate', Date('F j, Y', strtotime($startDate)));
        $templateProcessor->setValue('endRangeDate', Date('F j, Y', strtotime($endDate)));
        $templateProcessor->setValue('account_title', str_replace('&', '&amp;', strip_tags($request->accTitle)));
        $templateProcessor->cloneRow('or_number', $occurences);
        foreach ($landTaxInfo as $key => $info) {
            $grandTotal += str_replace(',', '', $info->totalAmount);
            $templateProcessor->setValue('or_number#'.($key+1), $info->serial_number);
            $templateProcessor->setValue('transact_date#'.($key+1), Date('M j, Y', strtotime($info->report_date)));
            
            if ($info->client_type_id == '2' || $info->client_type_id == '3' || $info->client_type_id == '14') {
                if ($info->business_name == null) {
                    $payor = $info->owner;
                } else if ($info->owner == null) {
                    $payor = $info->business_name;
                } else {
                    $payor = $info->business_name .' By: '. $info->owner;
                }
            } else if ($info->client_type_id == '4') {
                $payor = $info->parentMunicipality->municipality .', '. $info->parentBarangay->barangay_name;
            } else if ($info->client_type_id == '5') {
                $payor = 'Municipal Government of ' . $info->parentMunicipality->municipality;
            } else if ($info->client_type_id == '6' || $info->client_type_id == '7') {
                if ($info->trade_name_permittees != null && $info->permittee != null) {
                    $payor = str_replace('&', '&amp;', strip_tags($info->trade_name_permittees)).' By: '. $info->permittee;
                } else if ($info->trade_name_permittees != null && $info->permittee == null) {
                    $payor = str_replace('&', '&amp;', strip_tags($info->trade_name_permittees));
                } else if ($info->trade_name_permittees == null && $info->permittee != null) {
                    $payor = $info->permittee;
                }
            } else if ($info->client_type_id == '9') {
                $payor = $info->parentRentals->name;
            } else if ($info->client_type_id == '10' || $info->client_type_id == '11') {
                if ($info->trade_name_permit_fees != null && $info->proprietor != null) {
                    $payor = str_replace('&', '&amp;', strip_tags($info->trade_name_permit_fees)).' By: '. $info->proprietor;
                } else if ($info->trade_name_permit_fees != null && $info->proprietor == null) {
                    $payor = str_replace('&', '&amp;', strip_tags($info->company));
                } else if ($info->trade_name_permit_fees == null && $info->proprietor != null) {
                    $payor = $info->proprietor;
                }
            } else if ($info->client_type_id == '12' || $info->client_type_id == '13') {
                if ($info->bidders_business_name == null) {
                    $payor = $info->owner_representative;
                } else if ($info->owner_representative == null) {
                    $payor = str_replace('&', '&amp;', strip_tags($info->bidders_business_name));
                } else {
                    $payor = str_replace('&', '&amp;', strip_tags($info->bidders_business_name)).' By: '. $info->owner_representative;
                }
            } else {
                if ($info->client_type_radio == 'Individual') {
                    $payor = $info->first_name.' '.$info->middle_initial.' '.$info->last_name;
                } else if ($info->client_type_radio == 'Company') {
                    $payor = str_replace('&', '&amp;', strip_tags($info->company));
                } else {
                    $payor = str_replace('&', '&amp;', strip_tags($info->spouses));
                }
            }
            // dump($payor);
            $templateProcessor->setValue('payor#'.($key+1), $payor);
            $templateProcessor->setValue('receipt_remarks#'.($key+1), str_replace(array("\r\n","&nbsp;"), array("</w:t><w:br/><w:t xml:space='preserve'>", " "), strip_tags($info->receipt_remarks)));
            $templateProcessor->setValue('nature#'.($key+1), str_replace('&', '&amp;', strip_tags($info->nature)));
            $templateProcessor->setValue('total#'.($key+1), $info->totalAmount);
            
        }
        $templateProcessor->setValue('total_transact', $occurences);
        $templateProcessor->setValue('grand_total', number_format($grandTotal, 2, '.', ','));
        
        // SAVE DOCUMENT TO TEMPORARY RESULT FILE
        $resultFile = $templateProcessor->saveAs('storage/WordResults/results.docx');

        // Get the directory of the saved .docx file
        $resultPath = public_path().'\storage\WordResults\results.docx';
        // Initialize file name for the PDF
        $resultfilepath = public_path().'\storage\WordResults\PPMP_'.date('m_d_Y-h_i_s').'.pdf';
        $word = new \COM("Word.Application") or die ("Could not initialise Object.");
        $word->Visible = 0;
        $word->DisplayAlerts = 0;
        // Open existing docx file
        $word->Documents->Open($resultPath);
        // Convert to PDF file format
        // (OutputFileName, ExportFormat, OpenAfterExport, OptimizeFor, Range, From, To, Item, IncludeDocProps, KeepIRM, CreateBookmarks, DocStructureTags, BitmapMissingFonts, UseISO19005_1, FixedFormatExtClassPtr)
        $word->ActiveDocument->ExportAsFixedFormat($resultfilepath, 17, false, 0, 0, 0, 0, 7, true, true, 2, true, true, false);
        $word->Quit(false);
        // Close object
        unset($word);
        // Get .pdf file contents
        $fileopen = file_get_contents($resultfilepath, true);
        // Convert file contents to base64 to embed in iframe
        $data = base64_encode($fileopen);
        // Unlink/delete .docx file and .pdf file to prevent data buildup
        unlink($resultfilepath);
        unlink($resultPath);
        // Revert back the execution time to 60
        ini_set('max_execution_time', 60);
        return response()->json($data);
    }
}
