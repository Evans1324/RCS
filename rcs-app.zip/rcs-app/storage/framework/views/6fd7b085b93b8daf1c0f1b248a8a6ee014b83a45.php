

<?php $__env->startSection('content'); ?>
    <h1>Accounts Daily Reports</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['page' => __('Accounts Daily Reports'), 'pageSlug' => 'accounts_daily_reports'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rcs-app\resources\views/pages/accounts_daily_reports.blade.php ENDPATH**/ ?>