
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>Provincial Income Report</h1>
        </div>
    </div>
    
            <form name="pvet-report" id="pvet-form" method="post" action="<?php echo e(url('generateProvIncomeReport')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3 d-none">
                                        <label for="pvetID">ID</label>
                                    </div>

                                    <div class="col-md-3">
                                        <label for="piMonthStart">Month</label>
                                        <?php
                                            $selected_month = date('m');
                                            echo '<select class="sgMonthPicker form-control bg-white text-dark" name="piMonthStart" id="piMonthStart">'."\n";
                                            echo '<option></option>';
                                            for ($i_month = 1; $i_month <= 12; $i_month++) { 
                                                $selected = ($selected_month == $i_month ? ' selected' : '');
                                                echo '<option value="'.$i_month.'"'.$selected.'>'.date('F', mktime(0,0,0,$i_month,3,0)).'</option>'."\n";
                                            }
                                            echo '</select>'."\n";
                                        ?>
                                    </div>

                                    <div class="col-md-3">
                                        <label for="piYear">Year</label>
                                        <?php 
                                            $year_start  = 1940;
                                            $year_end = date('Y');
                                            $user_selected_year = date('Y');
                                            echo '<select class="sgMonthPicker form-control bg-white text-dark" name="piYear" id="piYear">'."\n";
                                            for ($i_year = $year_start; $i_year <= $year_end; $i_year++) {
                                                $selected = ($user_selected_year == $i_year ? ' selected' : '');
                                                echo '<option value="'.$i_year.'"'.$selected.'>'.$i_year.'</option>'."\n";
                                            }
                                            echo '</select>'."\n";
                                        ?>
                                    </div>

                                    <div id="officer" class="col-md-3">
                                        <label class="text-light" for="reportOfficerCol">Accountable Officers:</label>
                                        <select class="form-control bg-white text-dark" name="reportOfficerCol" id="reportOfficerCol">
                                            <option class="bg-white" value="IMDELDA I. MACANES">IMDELDA I. MACANES</option>
                                        </select>
                                        <label class="text-danger">
                                            <?php $__errorArgs = ['reportOfficerCol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="row mt-3">
                                    <div class="col-md-3">
                                        <button type="input" name="pdf_B" id="export-pdf-b" value="1" id="submit-btn" class="btn btn-success">Generate Report</button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        

    <script>
        let currentYear = (new Date).getFullYear();
        $('#counterCheckReportNumber').val(currentYear);
        
        function disableWeekends(date) {
            return (date.getDay() === 0 || date.getDay() === 6);
        }
        
        $('.datepicker').flatpickr({
            dateFormat: 'm/d/Y',
            disable: [disableWeekends]
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['page' => __('Provincial Income Report'), 'pageSlug' => 'provincial_income_report'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rcs-app\resources\views/pages/provincial_income_report.blade.php ENDPATH**/ ?>