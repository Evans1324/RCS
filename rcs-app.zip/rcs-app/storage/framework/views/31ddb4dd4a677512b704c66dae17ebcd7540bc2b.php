

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card">
            <div class="card-header">
                <h1 class="card-title">Collections & Deposits</h1>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo e(url('submitCollectionDepositReport')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="text-light" for="cdType">Type</label>
                                <select class="form-control bg-white text-dark" name="cdType" id="cdType">
                                    <option class="bg-white" value=""></option>
                                    <?php $__currentLoopData = $acc_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="bg-white" value="<?php echo e($acc->id); ?>"><?php echo e($acc->acc_category_settings); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label class="text-danger">
                                <?php $__errorArgs = ['cdType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                            </div>
    
                            <div class="col-md-4">
                                <label class="text-light" for="reportNumber">Report Number</label>
                                <input type="text" name="reportNumber" class="form-control mb-0 bg-white text-dark" id="reportNumber">
                                <label class="text-danger">
                                <?php $__errorArgs = ['reportNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <label class="text-light" for="reportDate">Report Date</label>
                                <input type="text" name="reportDate" class="bg-white datepicker form-control mb-0 text-dark" id="reportDate">
                                <label class="text-danger">
                                    <?php $__errorArgs = ['reportDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                            </div>
                            
                            <div class="col-md-4">
                                <label class="text-light" for="startDate">Start Date</label>
                                <input type="text" name="startDate" class="bg-white datepicker form-control mb-0 text-dark" id="startDate">
                                <label class="text-danger">
                                    <?php $__errorArgs = ['startDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                            </div>
    
                            <div class="col-md-4">
                                <label class="text-light" for="endDate">End Date</label>
                                <input type="text" name="endDate" class="bg-white datepicker form-control mb-0 text-dark" id="endDate">
                                <label class="text-danger">
                                    <?php $__errorArgs = ['endDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <h3 class="mb-1">Report Officers</h3>
                        </div>

                        <div class="row">
                            <div id="officer" class="col-md-4">
                                <label class="text-light" for="reportOfficerCol">Accountable Officer A</label>
                                <select class="form-control bg-white text-dark" name="reportOfficerCol" id="reportOfficerCol">
                                    <option class="bg-white" selected value="3">MARY JANE P. LAMPACAN - Local Revenue Collection Officer IV</option>
                                    <?php $__currentLoopData = $displayOfficers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="bg-white" value="<?php echo e($officer->id); ?>"><?php echo e($officer->name); ?> - <?php echo e($officer->position); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label class="text-danger">
                                    <?php $__errorArgs = ['reportOfficerCol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                            </div>

                            <div id="officer" class="col-md-4">
                                <label class="text-light" for="reportOfficerColB">Accountable Officer B</label>
                                <select class="form-control bg-white text-dark" name="reportOfficerColB" id="reportOfficerColB">
                                    <option class="bg-white" selected value="6">IRENE C. BAGKING</option>
                                    <?php $__currentLoopData = $displayOfficers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="bg-white" value="<?php echo e($officer->id); ?>"><?php echo e($officer->name); ?> - <?php echo e($officer->position); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label class="text-danger">
                                    <?php $__errorArgs = ['reportOfficerColB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                            </div>

                            <div id="officer" class="col-md-4">
                                <label class="text-light" for="reportOfficerColD">Accountable Officer D Certification</label>
                                <select class="form-control bg-white text-dark" name="reportOfficerColD" id="reportOfficerColD">
                                    <option class="bg-white" selected value="3">MARY JANE P. LAMPACAN - Local Revenue Collection Officer IV</option>
                                    <?php $__currentLoopData = $displayOfficers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="bg-white" value="<?php echo e($officer->id); ?>"><?php echo e($officer->name); ?> - <?php echo e($officer->position); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label class="text-danger">
                                    <?php $__errorArgs = ['reportOfficerColD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                            </div>

                            <div id="officer" class="col-md-4">
                                <label class="text-light" for="reportOfficerColV">Accountable Officer D Verification</label>
                                <select class="form-control bg-white text-dark" name="reportOfficerColV" id="reportOfficerColV">
                                    <option class="bg-white" selected value="6">IRENE C. BAGKING</option>
                                    <?php $__currentLoopData = $displayOfficers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="bg-white" value="<?php echo e($officer->id); ?>"><?php echo e($officer->name); ?> - <?php echo e($officer->position); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label class="text-danger">
                                    <?php $__errorArgs = ['reportOfficerColV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3">
                                <button type="input" name="pdf_B" id="export-pdf-b" value="1" class="btn btn-primary">Generate Report</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        function disableWeekends(date) {
            return (date.getDay() === 0 || date.getDay() === 6);
        }


        $('.datepicker').flatpickr({
            dateFormat: 'm/d/Y',
            disable: [disableWeekends],  
        });

        let currentYear = (new Date).getFullYear();
        $('#reportNumber').val(currentYear);
        $('#reportDate').val(moment().format("L"));
        $('#startDate').val(moment().format("L"));
        $('#endDate').val(moment().format("L"));

        $('#reportDate').change(function () {
            let value = $(this);
            $('#startDate').val($(value).val());
            $('#endDate').val($(value).val());
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['page' => __('Collections & Deposits'), 'pageSlug' => 'collections_deposits'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rcs-app\resources\views/pages/collections_deposits.blade.php ENDPATH**/ ?>