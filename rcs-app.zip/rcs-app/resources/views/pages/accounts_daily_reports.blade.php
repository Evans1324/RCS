@extends('layouts.app', ['page' => __('Accounts Daily Reports'), 'pageSlug' => 'accounts_daily_reports'])

@section('content')
    <h1>Accounts Daily Reports</h1>
@endsection