<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\ReportOfficers;
use App\Models\Officers;
use App\Models\Positions;
use App\Models\Department;
use App\Models\CertOfficers;

class ReportOfficersController extends Controller
{
    public function officerDataInsert (Request $request) 
    {
        $request->validate ([
            'officerName' => 'required',
            'officerPosition' => 'required'
        ]);

        // $officerData = new ReportOfficers;
        // $positionData = new Positions;
        // $departmentData = new Department;

        // Officers::upsert(
        //     ['id'=>$request->officerID, 'name'=>$request->officerName, 'created_at'=>now(), 'updated_at'=>now()],
        //     ['id'], ['name']
        // );

        // Positions::upsert(
        //     ['id'=>$request->officerID, 'position'=>$request->officerPosition, 'created_at'=>now(), 'updated_at'=>now()],
        //     ['id'],
        //     ['position']
        // );

        // Department::upsert(
        //     ['id'=>$request->officerID, 'department'=>$request->officerDepartment, 'created_at'=>now(), 'updated_at'=>now()],
        //     ['id'],
        //     ['department']
        // );

        // $test = CertOfficers::upsert(
        //     ['id'=>$request->officerID, 'officer_id'=>$request->officerNameID, 'position_id'=>$request->officerPositionID, 'department_id'=>$request->officerDeptID, 'created_at'=>now(), 'updated_at'=>now()],
        //     ['id'],
        //     ['officer_id', 'position_id', 'department_id']
        // );

        $pos = Positions::where('position', $request->officerPosition)->first();
        if(is_null($pos)) {
            $pos = new Positions;
            $pos->position=$request->officerPosition;
            $pos->save();
        }

        $officer = Officers::where('name', $request->officerName)->first();
        if(is_null($officer)) {
            $officer = new Officers;
            $officer->name=$request->officerName;
            $officer->save();
        }

        $dept = Department::where('department', $request->officerDepartment)->first();
        if(is_null($dept)) {
            $dept = new Department;
            $dept->department=$request->officerDepartment;
            $dept->save();
        }

        $cert = CertOfficers::where([['officer_id', $officer->id], ['position_id', $pos->id], ['department_id', $dept->id]])->first();
        if(is_null($cert)) {
            $cert = new CertOfficers;
            $cert->officer_id=$officer->id; 
            $cert->position_id=$pos->id;
            $cert->department_id=$dept->id;
            $cert->save();
        }

        return back()->withInput()->with('Message', 'Added');
    }

    public function officerDataDelete (Request $request)
    {
        $officerData = new CertOfficers;
        $deletedData = $officerData::find($request->officerID);
        $deletedData->deleted_at=now();
        $deletedData->save();
        return back()->with('Message', 'Successfully Deleted');
    }
}
