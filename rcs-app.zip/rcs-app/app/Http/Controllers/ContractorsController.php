<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Contractors;

class ContractorsController extends Controller
{
    public function addNewContractors(Request $request) {
        $insertInfo = Contractors::create(
            ['business_name'=>$request->businessName, 'owner'=>$request->owner, 'address'=>$request->address]
        );
        
        $message = 'Data Saved Succesfuly';
        return back()->withInput()->with('Message', $message);
    }

    public function saveNewContractors(Request $request) {
        $insertContractors = new Contractors;
        $insertInfo = $insertContractors::upsert(
            ['id'=>$request->contractorsID, 'business_name'=>$request->businessName, 'owner'=>$request->businessOwner, 'position'=>$request->businessPosition, 'address'=>$request->businessAddress, 'contact_number'=>$request->businessNumber],
            ['id'],
            ['business_name', 'owner', 'position', 'address', 'contact_number']
        );
        
        $message = 'Data Saved Succesfuly';
        return \Redirect::route('pages.land_tax_collection');
    }

    public function deleteContractors(Request $request) {
        $delContractors = new Contractors;
        $deletedData = $delContractors::where('id',$request->contractorsID)->update([
            'deleted_at' => now()
        ]);
        return back()->with('Message', 'Successfully Deleted');
    }
}
