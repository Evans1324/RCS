
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <h1>Counter Check Per Account Title</h1>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                
                    
                    <div class="row">
                        <div id="officer" class="col-md-6">
                            <label class="text-light" for="searchAccountTitles">Account Titles</label>
                            <input type="text" name="searchAccountTitles" class="bg-white form-control mb-0 text-dark" id="searchAccountTitles">
                            <label class="text-danger">
                                <?php $__errorArgs = ['reportOfficerCol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </label>
                        </div>

                        <div id="officer" class="col-md-6">
                            <label class="text-light" for="counterCheckReportNumber">Report Number</label>
                            <input type="text" name="counterCheckReportNumber" class="bg-white form-control mb-0 text-dark" id="counterCheckReportNumber">
                            <label class="text-danger">
                                <?php $__errorArgs = ['reportOfficerCol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </label>
                        </div>
                    </div>

                    <div class="row">
                        <div id="officer" class="col-md-6">
                            <label class="text-light" for="checkStartDate">Start Date</label>
                            <input type="text" name="checkStartDate" class="datepicker bg-white form-control mb-0 text-dark" id="checkStartDate">
                            <label class="text-danger">
                                <?php $__errorArgs = ['reportOfficerCol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </label>
                        </div>

                        <div id="officer" class="col-md-6">
                            <label class="text-light" for="checkEndDate">End Date</label>
                            <input type="text" name="checkEndDate" class="datepicker bg-white form-control mb-0 text-dark" id="checkEndDate">
                            <label class="text-danger">
                                <?php $__errorArgs = ['reportOfficerCol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </label>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-3">
                            <button id="genPreview" class="text-white btn btn-primary">Preview</button>
                        </div>
                    </div>
                
            </div>
        </div>
    </div>
</div>

<div id="container" class="d-flex align-items-center justify-content-center">
    <div id="loader" class="loader"></div>
    <div id="loader-text" class="loader-text">
        <p>Fetching Data</p>
    </div>
</div>

<script>
    
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function () {
        $('#loader').hide();
        $('#loader-text').hide();
        $('#checkStartDate').val(moment().format("L"));
        $('#checkEndDate').val(moment().format("L"));
    });

    let currentYear = (new Date).getFullYear();
    $('#counterCheckReportNumber').val(currentYear);

    function disableWeekends(date) {
        return (date.getDay() === 0 || date.getDay() === 6);
    }

    $('.datepicker').flatpickr({
        dateFormat: 'm/d/Y'
        , disable: [disableWeekends]
    });

    let trigger = 0;
    let autoCompleteData = [];
    var category_autocomplete = {
        minLength: 0,
        autocomplete: true,
        source: function(request, response) {
            $.ajax({
                'url': '<?php echo e(route('getAccountTitlesPIR')); ?>',
                'data': {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "term": request.term,
                },
                'method': "post",
                'dataType': "json",
                'success': function(data) {
                    autoCompleteData = data;
                    response(data);
                }
            });
        }
    }

    $("#searchAccountTitles").autocomplete(category_autocomplete).focus(function() {
        $(this).autocomplete('search', $(this).val());
    });

    $('#genPreview').click(function() {
        $('#loader').show();
        $('#loader-text').show();
        $.ajax({
            'url': '<?php echo e(route('generateProvIncomeCounterCheck')); ?>',
            'data': {
                "_token": "<?php echo e(csrf_token()); ?>",
                "accTitle": $('#searchAccountTitles').val(),
                "startDate": $('#checkStartDate').val(),
                "endDate": $('#checkEndDate').val()
            },
            'method': "post",
            'dataType': "json",
            'success': function(data) {
                $('#loader').hide();
                $('#loader-text').hide();
                let pdfWindow = window.open("");
                pdfWindow.document.write(
                    "<html><body style='margin: 0px!important; width: 100vw!important; height: 100vh!important; background-color: #aeaeae!important;'><iframe style='width: 99.8%!important; height: 99.6%!important' src='data:application/pdf;base64, " +
                    encodeURI(data) + "'></iframe></body></html>"
                )
            }
        });
    });
    

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['page' => __('Counter Check Reports'), 'pageSlug' => 'counter_check_reports'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rcs-app\resources\views/pages/counter_check_reports.blade.php ENDPATH**/ ?>