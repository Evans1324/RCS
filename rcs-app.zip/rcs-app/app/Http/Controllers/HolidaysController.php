<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Holidays;

class HolidaysController extends Controller
{
    public function holidaysDataInsert (Request $request)
    {
        $request->validate ([
            'dateOfHoliday' => 'required'
        ]);

        $holidays = new Holidays;
        $duplicateEntry = DB::table('holidays')->where('date_of_holiday', $request->dateOfHoliday)->where('holiday_name', $request->nameOfHoliday)->count();
        if($duplicateEntry > 0) {
            $message = "This data already exists";
        } else {
            $holidays::upsert(
                ['id'=>$request->dateID, 'date_of_holiday'=>$request->dateOfHoliday, 'holiday_name'=>$request->nameOfHoliday, 'created_at'=>now(), 'updated_at'=>now()],
                ['id'], ['date_of_holiday', 'holiday_name']
            );
            $message = 'Sucessfully Added';
        }
        return back()->withInput()->with('Message', $message);
    }

    public function holidaysDataDelete (Request $request)
    {
        $customerType = new Holidays();
        $deletedData = $customerType::where('id', $request->dateID)->update([
            'deleted_at' => now()
        ]);
        return back()->with('Message', 'Successfully Deleted');
    }
}
