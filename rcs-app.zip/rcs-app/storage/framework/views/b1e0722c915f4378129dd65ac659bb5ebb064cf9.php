<footer class="footer">
    <div class="container-fluid">
        
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\rcs-app\resources\views/layouts/footer.blade.php ENDPATH**/ ?>