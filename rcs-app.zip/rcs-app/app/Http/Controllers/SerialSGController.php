<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SerialSG;
use App\Models\LandTaxInfo;
use Illuminate\Support\Facades\DB;

class SerialSGController extends Controller
{
    public function insertSerialSGData(Request $request)
    {
        $landTaxInfo = new LandTaxInfo;
        $info = $landTaxInfo::where('dr_number', $request->endSG)->first();
        // $request->validate ([
        //     'inputType' => 'required',
        //     'inputCategoryType' => 'required'
        // ]);
        
        $serialSG = new SerialSG;
        $duplicateEntry = DB::table('serial_s_g_s')->where('start_serial_sg', $request->startSerialSG)->where('end_serial_sg', $request->endSerialSG)->where('serial_sg_type', $request->sgType)->count();
        if($duplicateEntry > 0) {
            $message = "This data already exists";
        } else {
            $serialSG::upsert(
                ['id'=>$request->id, 'start_serial_sg'=>$request->startSerialSG, 'booklets'=>$request->bookletAmount, 'end_serial_sg'=>$request->endSerialSG, 'serial_sg_type'=>$request->sgType, 'created_at'=>now(), 'updated_at'=>now()],
                ['id'], ['start_serial_sg', 'booklets', 'end_serial_sg', 'serial_sg_type']
            );
            $message = 'Sucessfully Added';
        }
        return back()->withInput()->with('Message', $message);
    }

    public function deleteSerialSGData(Request $request) 
    {
        $serialSG = new SerialSG;
        $deletedData = $serialSG::where('id',$request->serialSGID)->update([
            'deleted_at' => now()
        ]);
        return back()->with('Message', 'Successfully Deleted');
    }

    public function getCurrentDeliveryReceipts()
    {
        $sgQuery = SerialSG::select('start_serial_sg', 'end_serial_sg', 'serial_sg_type', 'status')
        ->where('status', 'Active')
        ->orderBy('id', 'asc')
        ->first();
        $currentDR = LandTaxInfo::where([['dr_number', '>=', $sgQuery->start_serial_sg], ['dr_number', '<=', $sgQuery->end_serial_sg]])
        ->orderBy('serial_number', 'desc')
        ->limit(1)
        ->first();
        return $currentDR;
    }

    public function sgDeliveryReceipts(Request $request)
    {
        $sgQuery = SerialSG::select('start_serial_sg AS value', 'end_serial_sg', 'serial_sg_type', 'status')
        ->where([['status', 'Active'], ['start_serial_sg', 'like', '%'.$request->term.'%']])
        ->orderBy('id', 'asc')
        ->get();
        return $sgQuery;
    }

    public function getCurrentSeriesSG(Request $request) 
    {
        $serialSG = DB::table('serial_s_g_s')
        ->select('*', DB::raw('CONCAT(start_serial_sg," - ", end_serial_sg) AS delReceipt'))
        ->where([['status', 'Active'], ['serial_s_g_s.id', $request->id]])
        ->first();
        // dd($serialSG);
        $currentOnDeckSG = LandTaxInfo::where([['dr_number', '>=', $serialSG->start_serial_sg], ['dr_number', '<=', $serialSG->end_serial_sg]])
        ->orderBy('dr_number', 'desc')
        ->limit(1)
        ->first();
        // dd($serialSG->start_serial_sg);
        if ($currentOnDeckSG != null) {
            if ($currentOnDeckSG->dr_number == $serialSG->end_serial_sg) {
                $currentOnDeckSG = 'Serial Error';
            } else {
                $currentOnDeckSG = $currentOnDeckSG->dr_number+50;
            }
        } else {
            $currentOnDeckSG = $serialSG->start_serial_sg;
        }
        
        return $currentOnDeckSG;
    }

}
