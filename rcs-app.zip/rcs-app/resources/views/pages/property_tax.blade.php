@extends('layouts.app', ['page' => __('Real Property Tax'), 'pageSlug' => 'property_tax'])

@section('content')
    <div class="row">
        <div class="card">
            <div class="card-header">
                <h1 class="card-title">Real Property Tax (Form 56)</h1>
            </div>
            <div class="card-body">
                <div class="col-md-12">
                    <div class="row">
                        <form name="submit_mun_receipt_form" id="submit_mun_receipt_form" method="post" action="{{ url('submit_mun_receipt_form') }}">
                            @csrf
                            <div class="card-body">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-3 d-none">
                                            <label for="munReceiptsID">ID</label>
                                            <input type="text" class="form-control" name="munReceiptsID" id="munReceiptsID">
                                        </div>
            
                                        <div class="col-md-2">
                                            <label for="munReceiptDate">Receipt Date</label>
                                            <input type="text" class="currentDate form-control mb-0 bg-white text-dark" name="munReceiptDate" id="munReceiptDate" value="{{ $current_date }}">
                                        </div>
            
                                        <div class="col-md-2">
                                            <label for="munReceiptNo">Receipt No.</label>
                                            <input type="text" class="form-control mb-0 bg-white text-dark" name="munReceiptNo"
                                                id="munReceiptNo">
                                        </div>
            
                                        <div class="col-sm-4">
                                                <label class="text-light" for="munReceiptClientType">Client Type</label>
                                                <select class="form-control bg-white text-dark" name="munReceiptClientType"
                                                    id="munReceiptClientType">
                                                    <option class="bg-white" value=""></option>
                                                    @foreach ($displayCustType as $cust_items)
                                                        <option class="bg-white" value="{{ $cust_items->id }}">
                                                            {{ $cust_items->description_type }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
            
                                        <div class="col-sm-2">
                                            <label class="text-light" for="munReceiptMunicipality">Municipality</label>
                                            <select readonly class="form-control bg-light text-dark" name="munReceiptMunicipality"
                                                id="munReceiptMunicipality">
                                                <option class="bg-white" value=""></option>
                                            </select>
                                        </div>
            
                                        <div id="munReceiptBarSelect" class="col-sm-2">
                                            <label class="text-light" for="munReceiptBarangay">Barangay</label>
                                            <select readonly class="form-control bg-light text-dark" name="munReceiptBarangay"
                                            id="munReceiptBarangay">
                                                <option class="bg-white" value=""></option>
                                            </select>
                                        </div>
                                    </div>
            
                                    <hr id="client-type-separator" class="bg-white d-none">
            
                                    <div id="client-type-others" class="row d-none ml-2">
                                        <div class="col-sm-2">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="clientTypeRadio" id="individualRadio" value="Individual" checked/>
                                                <label class="form-check-label text-light" for="individualRadio"> Individual </label>
                                            </div>
                                        </div>
            
                                        <div class="col-sm-2">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="clientTypeRadio" id="spousesRadio" />
                                                <label class="form-check-label text-light" for="spousesRadio"> SPS </label>
                                            </div>
                                        </div>
            
                                        <div class="col-sm-2">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="clientTypeRadio" id="companyRadio" />
                                                <label class="form-check-label text-light" for="companyRadio"> Company </label>
                                            </div>
                                        </div>
                                    </div>
            
                                    <div id="client-type-individual" class="row d-none">
                                        <div class="col-sm-3">
                                            <label class="text-light" for="munReceiptLastName">Last Name</label>
                                            <input type="text" name="munReceiptLastName" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptLastName">
                                        </div>
            
                                        <div class="col-sm-3">
                                            <label class="text-light" for="munReceiptFirstName">First Name</label>
                                            <input type="text" name="munReceiptFirstName" class="all-caps form-control mb-0 bg-white text-dark"
                                                id="munReceiptFirstName">
                                        </div>
            
                                        <div class="col-sm-1">
                                            <label class="text-light" for="munReceiptMI">M.I.</label>
                                            <input type="text" name="munReceiptMI" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptMI">
                                        </div>
            
                                        <div class="col-sm-1">
                                            <label class="text-light" for="munReceiptSex">Sex</label>
                                            <select class="form-control bg-white text-dark" name="munReceiptSex" id="munReceiptSex">
                                                <option class="bg-white" value=""></option>
                                                <option class="bg-white" value="M">M</option>
                                                <option class="bg-white" value="F">F</option>
                                            </select>
                                        </div>
                                    </div>
            
                                    <div id="client-type-spouse" class="row d-none">
                                        <div class="col-sm-4">
                                            <label class="text-light" for="munReceiptSpouses">Spouses</label>
                                            <input type="text" name="munReceiptSpouses" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptSpouses">
                                        </div>
                                    </div>
            
                                    <div id="client-type-company" class="row d-none">
                                        <div class="col-sm-4">
                                            <label class="text-light" for="munReceiptCompany">Company</label>
                                            <input type="text" name="munReceiptCompany" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptCompany">
                                        </div>
                                    </div>
            
                                    <div id="client-type-permittees" class="row d-none">
                                        <div class="col-sm-4">
                                            <label class="text-light" for="munReceiptPermittee">Permittee</label>
                                            <input type="text" name="munReceiptPermittee" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptPermittee">
                                        </div>
            
                                        <div class="col-sm-5">
                                            <label class="text-light" for="munReceiptPermitteeTradeName">Trade Name</label>
                                            <input type="text" name="munReceiptPermitteeTradeName" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptPermitteeTradeName">
                                        </div>
            
                                        <div class="col-sm-2">
                                            <div id="clientFieldPermittees"></div>
                                        </div>
                                    </div>
            
                                    <div id="client-type-permitFees" class="row d-none">
                                        <div class="col-sm-5">
                                            <label class="text-light" for="munReceiptPermitFeesTradeName">Trade Name</label>
                                            <input type="text" name="munReceiptPermitFeesTradeName" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptPermitFeesTradeName">
                                        </div>
            
                                        <div class="col-sm-4">
                                            <label class="text-light" for="munReceiptProprietor">Proprietor</label>
                                            <input type="text" name="munReceiptProprietor" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptProprietor">
                                        </div>
                                    </div>
            
                                    <div id="client-type-contractor" class="row d-none">
                                        <div class="col-sm-5">
                                            <label class="text-light" for="munReceiptBusinessName">Business Name</label>
                                            <input type="text" name="munReceiptBusinessName" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptBusinessName">
                                        </div>
            
                                        <div class="col-sm-4">
                                            <label class="text-light" for="munReceiptOwner">Owner</label>
                                            <input type="text" name="munReceiptOwner" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptOwner">
                                        </div>
            
                                        <div class="col-sm-4 d-none">
                                            <label class="text-light" for="munReceiptAddress">Address</label>
                                            <input type="text" name="munReceiptAddress" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptAddress">
                                        </div>
                                    </div>
            
                                    <div id="client-type-bidders" class="row d-none">
                                        <div class="col-sm-5">
                                            <label class="text-light" for="munReceiptBiddersBusinessName">Bidders Business Name</label>
                                            <input type="text" name="munReceiptBiddersBusinessName" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptBiddersBusinessName">
                                        </div>
            
                                        <div class="col-sm-3">
                                            <label class="text-light" for="munReceiptBiddersOwner">Owner/Representative</label>
                                            <input type="text" name="munReceiptBiddersOwner" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptBiddersOwner">
                                        </div>
            
                                        <div class="col-sm-2">
                                            <div id="clientFieldBidders"></div>
                                        </div>
                                    </div>
            
                                    <div id="client-type-rentals" class="row d-none">
                                        <div class="col-sm-3 d-none">
                                            <input type="text" name="munReceiptRentalID" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptRentalID">
                                        </div>
            
                                        <div class="col-sm-3">
                                            <label class="text-light" for="munReceiptRentalName">Rental Name</label>
                                            <input type="text" name="munReceiptRentalName" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptRentalName">
                                        </div>
            
                                        <div class="col-sm-4">
                                            <label class="text-light" for="munReceiptRentalLocation">Location</label>
                                            <input type="text" name="munReceiptRentalLocation" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptRentalLocation">
                                        </div>
            
                                        <div class="col-sm-3">
                                            <label class="text-light" for="munReceiptRentalLease">Lease of Contact</label>
                                            <input type="text" name="munReceiptRentalLease" class="form-control mb-0 bg-white text-dark"
                                                id="munReceiptRentalLease">
                                        </div>
            
                                        <div class="col-sm-2">
                                            <div id="clientField"></div>
                                        </div>
                                    </div>
            
                                    <hr class="bg-white">
            
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <label class="text-light" for="munReceiptTransaction">Transaction Type</label>
                                            <select class="form-control bg-white text-dark" name="munReceiptTransaction"
                                                id="munReceiptTransaction">
                                                <option class="bg-white" value="null"></option>
                                                <option class="bg-white" selected value="Cash">Cash</option>
                                                <option class="bg-white" value="Check">Check</option>
                                                <option class="bg-white" value="Check">Check & Cash</option>
                                                <option class="bg-white" value="Money Order">Money Order</option>
                                                <option class="bg-white" value="ADA-LBP">ADA-LBP</option>
                                                <option class="bg-white" value="Bank Deposit/Transfer">Bank Deposit/Transfer</option>
                                            </select>
                                        </div>
            
                                        <div class="col-sm-3">
                                            <label class="text-light" for="munReceiptBank">Bank Name</label>
                                            <input readonly type="text" name="munReceiptBank"
                                                class="edit-trigger form-control mb-0 text-dark" id="munReceiptBank">
                                        </div>
            
                                        <div class="col-sm-3">
                                            <label class="text-light" for="munReceiptNumber">Number</label>
                                            <input readonly type="text" name="munReceiptNumber"
                                                class="edit-trigger form-control mb-0 text-dark" id="munReceiptNumber">
                                        </div>
            
                                        <div class="col-sm-3">
                                            <label class="text-light" for="munReceiptTransactDate">Date</label>
                                            <input readonly type="text" name="munReceiptTransactDate"
                                                class="edit-trigger datepicker form-control mb-0 text-dark" id="munReceiptTransactDate">
                                        </div>
            
                                        <div id="bankRemarks" class="col-sm-12 d-none">
                                            <label class="text-light" for="munReceiptBankRemarks">Bank Remarks</label>
                                            <textarea id="munReceiptBankRemarks" name="munReceiptBankRemarks"></textarea>
                                        </div>
            
                                        <div class="col-md-3">
                                            <label class="text-light" for="munReceiptCert">With Certificate</label>
                                            <select class="form-control bg-white text-dark" name="munReceiptCert" id="munReceiptCert">
                                                <option class="bg-white" selected value="None">None</option>
                                                <option class="bg-white" value="Transfer Tax">Transfer Tax</option>
                                                <option class="bg-white" value="Sand & Gravel">Sand & Gravel</option>
                                                <option class="bg-white" value="Provincial Permit">Provincial Permit</option>
                                                <!-- <option class="bg-white" value="Sand & Gravel Cert">Sand & Gravel Certification</option> -->
                                            </select>
                                        </div>
                                    </div>
            
                                    <hr class="bg-white">
            
                                    <div class="row account" id="account">
                                        <div class="col-sm-12">
                                            <div class="table-responsive">
                                                <table class="table tablesorter" id="new-land-tax-table">
                                                    <thead>
                                                        <tr>
                                                            <th class="bg-dark">Account</th>
                                                            <th class="bg-dark"></th>
                                                            <th class="bg-dark"></th>
                                                            <th class="bg-dark"></th>
                                                            <th class="bg-dark">Nature</th>
                                                            <th class="bg-dark">Amount</th>
                                                            <th class="bg-dark">
                                                                <button id="addRowAccount" type="button"
                                                                    class="btn btn-info btn-sm tim-icons icon-simple-add"></button>
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="inputRow">
                                                        <tr>
                                                            <td class="d-none">
                                                                <input type="text" id="munReceiptAccountID" name="munReceiptAccountID"
                                                                    class="munReceiptAccountID form-control mb-0 bg-white text-dark">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="munReceiptAccount[]"
                                                                    class="munReceiptAccount form-control mb-0 bg-white text-dark">
                                                            </td>
                                                            <td>
                                                            </td>
                                                            <td>
                                                                <input readonly type="text" name="munReceiptTypeRate[]"
                                                                    class="d-none munReceiptTypeRate bg-light form-control mb-0 text-dark">
                                                            </td>
                                                            <td>
                                                                <input readonly type="text" name="munReceiptQuantity[]"
                                                                    class="d-none munReceiptQuantity bg-light form-control mb-0 text-dark">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="munReceiptNature[]"
                                                                    class="munReceiptNature form-control mb-0 bg-white text-dark">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="munReceiptAmount[]"
                                                                    class="munReceiptAmount form-control mb-0 bg-white text-dark">
                                                            </td>
            
                                                            <td></td>
                                                        </tr>
            
                                                    </tbody>
                                                    <tbody>
                                                        <tr>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td>
                                                                <input type="text" id="munReceiptTotal" name="munReceiptTotal"
                                                                    class="form-control mb-0 bg-light text-dark" id="munReceiptTotal">
                                                            </td>
                                                            <td>
            
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
            
                                    <div id="remarks" class="row mt-5">
                                        <div class="col-sm-12">
                                            <label class="text-light" for="munReceiptRemarks">Receipt Remarks</label>
                                            <textarea id="munReceiptRemarks" name="munReceiptRemarks"></textarea>
                                        </div>
                                    </div>
            
                                    <div class="row">
                                        <div class="col-md-3">
                                            <button type="button" id="submit-btn" class="btn btn-success mt-4">Save</button>
                                            <div id="edit-buttons" class="d-none btn-group">
                                                <button type="button" id="update-btn" class="btn btn-success mt-4">Update</button>
                                                <button type="button" id="clear-btn" class="btn btn-warning mt-4">Clear</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection