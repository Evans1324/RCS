<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RateScheduleController extends Controller
{
    //
}
